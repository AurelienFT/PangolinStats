let color = '#3aa757';

chrome.runtime.onInstalled.addListener(() => {
  //result.values.avax_eth
});